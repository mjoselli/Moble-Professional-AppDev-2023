//
//  TddTestsApp.swift
//  TddTests
//
//  Created by Mark Joselli on 03/08/23.
//

import SwiftUI

@main
struct TddTestsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
