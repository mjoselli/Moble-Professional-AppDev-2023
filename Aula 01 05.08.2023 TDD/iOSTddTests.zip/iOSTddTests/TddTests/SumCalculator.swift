//
//  SumCalculator.swift
//  TddTests
//
//  Created by Mark Joselli on 03/08/23.
//

import Foundation

struct SumCalculator {
    static func calculate(_ num1:Int,_ num2 :Int) -> Int {
        return num1 + num2
    }
}
